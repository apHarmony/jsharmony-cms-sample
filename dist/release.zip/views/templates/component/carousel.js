component.onRender = function(element, data, properties) {
  var carousel = new aphCarousel($(element).children('.cmptCarousel'));
}