var jsHarmonyCMS = require('jsharmony-cms');

var jsh = new jsHarmonyCMS.Application();

jsh.Run();
